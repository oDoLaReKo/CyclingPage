//kolejne przyklady uzycia jquery 
let container=$('#container');
console.log(container);
container.append('<div>Zapraszam do oglądania</div>');
container.append('<button id="zmienKolory"></button>');
let button=$('button');


button.css('height','50px');
button.css('width','50px');
button.css('margin','50px');
button.addClass('klasa');

let funkcja=function(){
    console.log("Przykładowy text w konsoli");
    alert("Zapraszam do obejrzenia motywujących zdjęc przeglądu części i kotaktu");
container.css('background-color', 'blue');
container.css('text-align','center');
container.append('<a href="../Rowerowo.html"><img src="foto.png"></a>');
button.prop('disabled','true');
button.css('background-color','grey')
}
button.click(funkcja);



