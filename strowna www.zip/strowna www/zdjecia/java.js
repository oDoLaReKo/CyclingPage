
let slider=undefined;
slider=document.getElementsByClassName("sliderv2");
const zdjecia=document.querySelectorAll('img');



let licznik=0;

console.log(slider);
const rozmiar=zdjecia[0].clientWidth;
console.log(rozmiar);
//document.getElementsByClassName("sliderv2").style.width='20%';

slider[0].style.transform='translateX('+(-rozmiar*licznik)+'px)';

//przyciski
const przyciskinext=document.querySelector('#buttonnext');
const przyciskpriv=document.getElementById("buttonpriv");
console.log(przyciskpriv);
let nastepneZdjecie=function()
{
    if(licznik==zdjecia.length-1){licznik=-1}
    licznik++;
    slider[0].style.transform='translateX('+(-rozmiar*licznik)+'px)';
    slider[0].style.transition=' transform 0.4s ease '
};
let poprzednieZdjecie=function()
{
    if(licznik==0){licznik=zdjecia.length}
    licznik--;
    slider[0].style.transform='translateX('+(-rozmiar*licznik)+'px)';
    
    slider[0].style.transition=' transform 0.4s ease '
};


przyciskinext.addEventListener('click',nastepneZdjecie);
przyciskpriv.addEventListener('click',poprzednieZdjecie);
