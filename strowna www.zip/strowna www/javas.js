
window.addEventListener("load",function(){

    let zaloguj=document.getElementById("zaloguj");
    console.log(zaloguj);
    let mojAlert=function(){alert("Funkcja dostepna w drugiej czesci zaliczenia za utrudnienia przepraszamy")}
    zaloguj.addEventListener('click',mojAlert);
})

let lewemenu=this.document.getElementById('leweMenu');
    let menuButton=document.getElementById("buttonlm");
   
    function showaj(){
        lewemenu.style.transform='translateX('+-200+'%)';
        menuButton.addEventListener('click',wysun);

    }
    function wysun(){

        lewemenu.style.transform='translateX('+0+'%)';
        menuButton.removeEventListener('click',wysun);
        menuButton.addEventListener('click',showaj);
    }
    
  
    menuButton.addEventListener('click',wysun);
    


