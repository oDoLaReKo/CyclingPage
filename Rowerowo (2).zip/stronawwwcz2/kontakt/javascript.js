

let button=$('#but');
let email=$('#email');
let tematRozmowy=$('#tematRozmowy');
let wiadomosc=$('#text');
let wyslij=$('#wyslij');
let resetuj=$('#reset');
console.log(wyslij[0]);
resetuj[0].addEventListener('click',()=>{ wyslij[0].disabled=true;})

let odblokuPrzycisk=function(){
    wyslij[0].disabled=false;
    

};

let sprawdzanie=function() {
    if(email[0].value.indexOf('@')>0&&email[0].value.length>2&&email[0].value.indexOf('@')<email[0].value.length-1)
    {email[0].style.background='white';
    
       if(tematRozmowy[0].value!="")
       { tematRozmowy[0].style.background='white'; 
           if(wiadomosc[0].value.length<10)
              { wiadomosc[0].style.background='red';
                  alert("Napisz konkretna wiadomosc i nie marnuj mojego czasu!");}
           
           else{
            wiadomosc[0].style.background='white';
               alert("Formularz poprawny odblokowuje funkcje wyślij");
               odblokuPrzycisk();}
        }

       else{alert("Wybierz temat rozmowy!");
    tematRozmowy[0].style.background='red';
    }}
    
    
    else{
        alert("Popraw mail !");
        email[0].style.background='red';
    }}
    
let mojAlert=function() {
alert("Dobra wiadomość: twój formularz został wysłany !");
alert("Zła wiadomość: raczej nie dojdzie gdyż jeszcze nie umiem w PHP :/");
};



button[0].addEventListener('click',()=>{sprawdzanie()});
wyslij[0].addEventListener('click',()=>{mojAlert()});



