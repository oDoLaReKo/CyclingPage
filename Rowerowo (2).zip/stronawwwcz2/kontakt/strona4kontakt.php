

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
  integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
  crossorigin="anonymous"></script> <!--jquery bibliotka -->
    <title>Document</title>
</head>
<body>
    <div id="container">
    <div id="form" ><h1>Formularz Kontaktowy</h1>
    
        <form action="strona4kontakt.php" id="formularz" method="post">
            <p >Imię: <input id="a1" type="text" name="imie" size="20" maxlength="25" placeholder="np.Janek"> </p> 
            <p>Nazwisko: <input type="text" name="nazwisko" size="20" maxlength="25" placeholder="np.Kowalski"> </p> 
            <div id="Plec">
                Wybierz Plec: 
                <label class="rodzajePlci"><input type="radio" name="plec" value="Kobieta" />Kobieta</label>
                <label class="rodzajePlci"><input type="radio" name="plec" value="Man" />Mężczyzna</label>
                <label class="rodzajePlci"><input type="radio" name="plec" value="Inne" />Inna</label>
               
                </div>
           
            <p>Email: <input id="email" type="email" name="e-mail" placeholder="np.swswswsw.@gmail.com" require > </p>
        <label>Temat rozmowy:</label> 
            <select id="tematRozmowy" name="tetamRozmowy" required >
                <option selected value="">Wybierz z poniższych tematów:</option>
                <option>Porada</option>
                <option>Zakup</option>
                <option>Rozmowa</option>
                <option>Błąd na stronie</option>
            </select><br>
            
           
      
       <br>
       <div id="wiadomosc" >Wiadomość: <br>
        <P></P>
        <textarea name="tekst" id="text" cols="30" rows="10" placeholder="Miejsce na twoją wiadomość"></textarea>
    </div>
    <div id="buttons">
<p><input type="submit" value="Wyślij"  disabled='disabled'  id="wyslij" >  <!--   disabled='disabled'   -->
     
   <input id="reset" type="reset" value="Restartuj"><p>

    
</div>
</form> 
<?php



if(isset($_POST['imie'] )){

$email=$_POST['e-mail'];
$subject=$_POST['tetamRozmowy'];
$to = "naszMail@przyklad.com";
$message=$_POST["tekst"];
$headers = "From: ".$email."";
mail($to,$subject,$message,$headers);
}
else
echo "<h1>"."brak name"."</h1>";


?>



<button id="but">sprawdz formularz</button> 
</div>

<script src="javascript.js"></script> 

</div>
</body>
</html>