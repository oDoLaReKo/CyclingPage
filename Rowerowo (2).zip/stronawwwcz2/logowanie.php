<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body style= "height: 100%;
    margin: 0px;
    
    background-image: url('background.jpg');
    background-attachment:fixed;
    background-size: cover;">
   
    <div id="content" style="border: 1px white solid; margin: 0 auto;
     ; display:inline-block;  position: absolute;  
        top: 40%;  
        left: 50%;  
        transform: translate(-40%, -50%); background-color: rgb(214, 192, 159,0.5); 
        ">
    
<form action="#" method="post" style="margin: 2em;">
    <div>Witamy w panelu logowania</div>
    <p  >Login: <input  type="text" name="login" size="20" maxlength="25"> </p> 
    <p>Haslo: <input type="password" name="haslo" size="20" maxlength="25"> </p> 
    <p><input type="submit" value="Zaloguj" >

</form >
<div style="margin:1em; margin-bottom:1em"  ><a  style="text-decoration: none;" href="rejestracja.php">Nie jesteś zarejestrowany ? Zrób to teraz !</a></div>
</div>
<?php


$host='localhost';
$user='root';
$password='';
$db='log';
$con = new mysqli('localhost', $user, $password, $db) or die("Unable to connect");


if(isset($_POST['login']))
{
$username=$_POST['login'];
$userpassword=$_POST['haslo'];
$sql="select * from login where user ='".$username."'and password='".$userpassword."'limit 1";//zapytanie do bazy
$result=mysqli_query($con,$sql);//wynik

if(mysqli_num_rows($result)==1){//sprawdzenie czy istnieje dany uzytkownik
    echo '<script language="javascript">';
echo 'alert("udalo sie zalogowac!")';

echo '</script>';
header("Refresh: 0.1; URL=Rowerowo.html");


exit();}
echo '<script language="javascript">';
echo 'alert("nie udalo sie zalogowac")';

echo '</script>';

exit();
};


?>


</div>
</body>
</html>