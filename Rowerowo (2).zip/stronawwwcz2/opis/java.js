//kolejne przyklady uzycia jquery 

let container=$('#container');

container.append('<button id="zmienKolory"><i class="fa-solid fa-bicycle" style="color: aliceblue; font-size:2em"></i></button>');
let button=$('button');


button.css('height','50px');
button.css('width','50px');
button.css('margin','50px');
button.addClass('klasa');

let funkcja=function(){
    container.append('<div><h2>Zapraszam do oglądania</h2></div>');

    console.log("Przykładowy text w konsoli");
    alert("Zapraszam do obejrzenia motywujących zdjęc przeglądu części i kotaktu");

    button.css('visibility','hidden');
    
    button.css('width','0px');
    button.css('height','0px');
container.append('<a href="../Rowerowo.html"><img src="foto.png"></a>');


}
button.click(funkcja);


function loadMain(){
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
		document.getElementById("container").innerHTML = this.responseText;
    }
  };
  

  xhttp.open("GET", 'podstronaAjax.html', true);
  xhttp.send();
}

function loadMain2(){
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
		document.getElementById("container").innerHTML = this.responseText;
    }
  };
  

  xhttp.open("GET", 'a.html', true);
  xhttp.send();
}

function loadMain3(){
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
		document.getElementById("container").innerHTML = this.responseText;
    }
  };
  

  xhttp.open("GET", 'podstronaAjax3.html', true);
  xhttp.send();
}





document.getElementsByClassName("pozycjamenu")[0].addEventListener('click',loadMain);

document.getElementsByClassName("pozycjamenu")[1].addEventListener('click',loadMain2);

document.getElementsByClassName("pozycjamenu")[2].addEventListener('click',loadMain3);




    
