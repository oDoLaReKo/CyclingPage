<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body style= "height: 100%;
    margin: 0px;
    
    background-image: url('background.jpg');
    background-attachment:fixed;
    background-size: cover;">
   
    <div id="content" style="border: 1px white solid; margin: 0 auto;
     ; display:inline-block;  position: absolute;  
        top: 40%;  
        left: 50%;  
        transform: translate(-40%, -50%); background-color: rgb(214, 192, 159,0.5); 
        ">
    
<form action="#" method="post" style="margin: 2em;">
    <div>Witamy w panelu Rejestraji</div>
    <p>Login: <input  type="text" name="login" size="20" maxlength="25"> </p> 
    <p>Haslo: <input type="password" name="haslo" size="20" maxlength="25"> </p> 
    <p><input type="submit" value="Stwórz konto" >

</form>
</div>
<?php
$host='localhost';
$user='root';
$password='';
$db='log';
$con = new mysqli('localhost', $user, $password, $db) or die("Unable to connect");//polaczenie

if(isset($_POST['login'])&&isset($_POST['haslo'])){

    $nowylogin=$_POST['login'];
    $nowehaslo=$_POST['haslo'];
        if($nowylogin!=""&&$nowehaslo!=""){
         $sprawdzIstniejacyUser="select * from login where user ='". $nowylogin."'limit 1";                      
         $result=mysqli_query($con,$sprawdzIstniejacyUser); 
            
         if(mysqli_num_rows($result)==1){//sprawdzenie czy sa jakies wyszukania co sugeruje istnienie uzytkowanika o podanym nicku
            echo '<script language="javascript">';
                echo 'alert("podany uzytkownik juz istnieje wprowadz inne dane")';
                echo '</script>';
            }
            else{         
                $query="insert into login (user,password) values('$nowylogin','$nowehaslo')";
                mysqli_query($con,$query);
                header("Refresh: 0.1; URL=logowanie.php");
                echo '<script language="javascript">';
                echo 'alert("Pomyślnie dodany użytkownik!")';
                echo '</script>';
                
            }

               
        }
        else if($nowylogin==""||$nowehaslo=="") 
        {
            echo '<script language="javascript">';
            echo 'alert("Nie podano danych spróbuj pownownie")';
            echo '</script>';
        };
                                                        
                                                       
                                                    }




/*else if(empty($nowylogin) || empty($nowehaslo)){echo "wypełnij pola";}*/








?>