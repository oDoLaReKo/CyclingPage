
let lat;
let long;
const apiKey="248d369aa6322178f4f2620b2da7f29c";
function error()
{
    console.log('Unable to retrieve your location');
    let city1="Brak danych";
    let temp="Brak danych";
    let wsch="Brak danych";
    let zach="Brak danych";
    let temod="Brak danych";
    let wilgo="Brak danych";
    let locationlink="Brak danych";
    locationlink.innerHTML="Brak danych";
    

  document.getElementById("linkmapa").innerHTML=city1;
    document.getElementById("temp").innerHTML=temp;
    document.getElementById("tempOdcz").innerHTML=temod;
    document.getElementById("wsch").innerHTML=wsch;
    document.getElementById("zach").innerHTML=zach;
    document.getElementById("wilg").innerHTML=wilgo;
    

}
function startApp()
{
    
    if(navigator.geolocation)
    {
       navigator.geolocation.getCurrentPosition(
           (position)=>{
lat=position.coords.latitude;
long=position.coords.longitude;
getWeatcherData();
           },error)

           
    }

  
}
function getWeatcherData()
{
    let url=`https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${long}&units=metric&appid=${apiKey}`;
   fetch(url).then(function(response)
   {
       response.json().then(function(data)
       {
        console.log(data);
        updateWeatcher(data);
       });
   });

   
}
function updateWeatcher(data)
{
    let city1=data.name;
    let temp=data.main.temp.toFixed(1);
    let wsch=new Date(data.sys.sunrise*1000);
    let zach=new Date(data.sys.sunset*1000);
    let temod=data.main.feels_like.toFixed(1);
    let wilgo=data.main.humidity;
    let locationlink=document.getElementById("linkmapa");
    locationlink.innerHTML=city1;
    locationlink.href=`https://www.google.pl/maps/@${lat},${long}z`

  
    document.getElementById("temp").innerHTML=temp+" °C";
    document.getElementById("tempOdcz").innerHTML=temod+" °C";
    document.getElementById("wsch").innerHTML=wsch.getHours()+":"+wsch.getMinutes()+":"+wsch.getSeconds();
    document.getElementById("zach").innerHTML=zach.getHours()+":"+zach.getMinutes()+":"+zach.getSeconds();
    document.getElementById("wilg").innerHTML=wilgo+" %";
    let imgUrl="http://openweathermap.org/img/wn/"+data.weather[0].icon+"@2x.png"
    document.getElementById("zdjecie").setAttribute("src",imgUrl);
}

